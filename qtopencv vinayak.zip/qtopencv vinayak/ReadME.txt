Instructions to use:

Press <start> to start the video feed
pressing <pause> causes the video feed to pause
pressing <face detection> causes the face detection to start running
turning up the <slider> causes edge detection to start functioning

Edge detection and face detection don't run together
when one starts the other stops and vice-versa